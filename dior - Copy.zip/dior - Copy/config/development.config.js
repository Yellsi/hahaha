module.exports = {
    url: 'mongodb://localhost:27017/express-mongo-app'
}